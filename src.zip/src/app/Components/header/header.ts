import { Component, ElementRef, HostListener, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './header.html',
  styleUrl: './header.scss'
})
export class Header implements OnInit {

  isScrolled = false;
  isMenuOpen = false;
  activeLink = '#hero';

  constructor(private elementRef: ElementRef) { }

  ngOnInit(): void {
    this.handleNavScroll();
    this.highlightActiveNav();
  }

  @HostListener('window:scroll')
  onWindowScroll(): void {
    this.handleNavScroll();
    this.highlightActiveNav();
  }

  private handleNavScroll(): void {
    this.isScrolled = window.scrollY > 50;
  }

  toggleMobileMenu(): void {
    this.isMenuOpen = !this.isMenuOpen;
    document.body.style.overflow = this.isMenuOpen ? 'hidden' : '';
  }

  closeMobileMenu(): void {
    this.isMenuOpen = false;
    document.body.style.overflow = '';
  }

  onNavClick(event: Event, href: string): void {
    event.preventDefault();
    this.closeMobileMenu();

    const target = document.querySelector(href);
    if (!target) return;

    const navbar = this.elementRef.nativeElement.querySelector('.navbar') as HTMLElement;
    const offset = navbar ? navbar.offsetHeight : 0;
    const pos = target.getBoundingClientRect().top + window.scrollY - offset;

    window.scrollTo({ top: pos, behavior: 'smooth' });
  }

  private highlightActiveNav(): void {
    const sections = document.querySelectorAll('section[id]');
    if (!sections.length) return;

    const scrollPos = window.scrollY + 150;

    sections.forEach((section) => {
      const el = section as HTMLElement;
      const top = el.offsetTop;
      const height = el.offsetHeight;
      const id = el.getAttribute('id');

      if (scrollPos >= top && scrollPos < top + height && id) {
        this.activeLink = `#${id}`;
      }
    });
  }
}