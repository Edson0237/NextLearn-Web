import { AfterViewInit, Component, ElementRef, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';

type AlertType = 'android' | 'ios' | null;

@Component({
  selector: 'app-accueil',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './accueil.html',
  styleUrl: './accueil.scss'
})
export class Accueil implements AfterViewInit, OnDestroy {

  isVisible = false;
  showAlert = false;
  alertType: AlertType = null;

  private observer?: IntersectionObserver;

  constructor(private elementRef: ElementRef) {}

  ngAfterViewInit(): void {
    this.observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            this.isVisible = true;
            this.observer?.disconnect();
          }
        });
      },
      { rootMargin: '0px 0px -60px 0px', threshold: 0.1 }
    );

    const hero = this.elementRef.nativeElement.querySelector('.hero');
    if (hero) this.observer.observe(hero);
  }

  ngOnDestroy(): void {
    this.observer?.disconnect();
  }

  onAndroidClick(event: Event): void {
    event.preventDefault();
    this.alertType = 'android';
    this.showAlert = true;
  }

  onIosClick(event: Event): void {
    event.preventDefault();
    this.alertType = 'ios';
    this.showAlert = true;
  }

  confirmAndroidDownload(): void {
    this.closeAlert();
    window.location.href = 'apk/nextlearn_v1_1.0_android.apk';
  }

  confirmIosRedirect(): void {
    this.closeAlert();
    window.open('https://frontend-v1-nextlearn-mobile.vercel.app/', '_blank', 'noopener,noreferrer');
  }

  closeAlert(): void {
    this.showAlert = false;
    this.alertType = null;
  }

  onOverlayClick(event: Event): void {
    if (event.target === event.currentTarget) {
      this.closeAlert();
    }
  }
}