import { Component, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { Header } from './Components/header/header';
import { Accueil } from './Components/accueil/accueil';
import { About } from './Components/about/about';
import { Contact } from './Components/contact/contact';
import { Equipe } from './Components/equipe/equipe';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, Header, Accueil, About, Contact, Equipe],
  templateUrl: './app.html',
  styleUrl: './app.scss'
})
export class App {
  protected readonly title = signal('nextLearn-web');
}
